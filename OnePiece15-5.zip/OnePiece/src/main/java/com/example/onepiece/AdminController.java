package com.example.onepiece;

import com.example.onepiece.relations.Item;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class AdminController {

    @FXML
    private Button homeButton;
    @FXML
    private Button logoutButton;
    @FXML
    private Button searchButton;
    @FXML
    private Button addItemButton;
    @FXML
    private Button removeItemButton;
    @FXML
    private TextField itemName;
    @FXML
    private ListView<String> itemList;
    
    Connection c = ConnectDatabase.connect();
    ResultSet rs;
    Statement stmt;
    
    @FXML
    void ActionOnHomeButton(ActionEvent event) throws IOException {
        AppMain m = new AppMain();
        m.changeScene("HomePage.fxml");
    }

    @FXML
    void ActionOnLogoutButton(ActionEvent event) throws IOException {
        AppMain m = new AppMain();
        m.changeScene("LoginForm.fxml");

    }

    @FXML
    void ActionOnSearchButton(ActionEvent event) {
        try {
            String searchName = itemName.getText();
            String query;
            stmt = c.createStatement();
            ArrayList<String> items = new ArrayList<>();
            itemList.getItems().clear();
            if(!searchName.equals("")){ 
              //  query = "SELECT * FROM items WHERE name = '" + searchName + "';";
                query =  "SELECT * FROM items;";
               query = String.format("SELECT * FROM items WHERE name = '%s';", searchName);
            }
            else{
                query =  "SELECT * FROM items;";
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                int id = rs.getInt("item_id");
                String name = rs.getString("name");
                String category = rs.getString("category");
                items.add("id: " + id + "\tname: " + name +"\tcategory: " + category);
            }
            itemList.getItems().addAll(items);
        } catch (SQLException ex) {
            Logger.getLogger(AdminController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void ActionOnAddItemButton(ActionEvent event) {
          /*
        pass from and to frontend
        unittest
        login credentials from db
        */
    }

    @FXML
    void ActionOnRemoveItemButton(ActionEvent event) {
        
        try {
            c.setAutoCommit(false);
            stmt = c.createStatement();
            //String query = String.format("DELETE FROM items WHERE id = %d", DeleteId); 
            stmt.executeUpdate("DELETE FROM items WHERE " + "");
            c.commit();
                    
        } catch (SQLException ex) {
            Logger.getLogger(AdminController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
